package com.itsupport.elevator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElevatorApplicationTests {

    @Test
    void contextLoads() {
    }

}
