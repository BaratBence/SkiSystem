package com.itsupport.skibackend.models;

public enum EUserRole {
    ROLE_USER,
    ROLE_ADMINISTRATOR
}
